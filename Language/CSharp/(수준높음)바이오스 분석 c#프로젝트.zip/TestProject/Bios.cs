﻿using System;
using System.ComponentModel;
using System.Globalization;
using System.Management;

namespace TestProject
{
    /// <summary>
    /// 바이오스
    /// </summary>
    public class BIOS : Component
    {
        //////////////////////////////////////////////////////////////////////////////////////////////////// Field
        ////////////////////////////////////////////////////////////////////////////////////////// Static
        //////////////////////////////////////////////////////////////////////////////// Private
        
        #region Field

        /// <summary>
        /// WMI 네임스페이스
        /// </summary>
        private static string _wmiNamespace = "ROOT\\CIMV2";
        
        /// <summary>
        /// 클래스명
        /// </summary>
        private static string _className = "Win32_BIOS";
        
        /// <summary>
        /// 관리 범위
        /// </summary>
        private static System.Management.ManagementScope _managementScope = null;
        
        #endregion

        ////////////////////////////////////////////////////////////////////////////////////////// Instance
        //////////////////////////////////////////////////////////////////////////////// Private

        #region Field

        /// <summary>
        /// 관리 시스템 속성
        /// </summary>
        private ManagementSystemProperties managementSystemProperties;
        
        /// <summary>
        /// 관리 객체
        /// </summary>
        private System.Management.ManagementObject managementObject;
        
        /// <summary>
        /// 자동 커밋 여부
        /// </summary>
        private bool automaticCommit;
        
        /// <summary>
        /// 중첩 관리 기본 객체
        /// </summary>
        private System.Management.ManagementBaseObject embeddedManagementBaseObject;
        
        /// <summary>
        /// 현재 관리 기본 객체
        /// </summary>
        private System.Management.ManagementBaseObject currentManagementBaseObject;
        
        /// <summary>
        /// 중첩 여부
        /// </summary>
        private bool isEmbedded;

        #endregion

        //////////////////////////////////////////////////////////////////////////////////////////////////// Property
        ////////////////////////////////////////////////////////////////////////////////////////// Public

        #region 원본 네임스페이스 - OriginatingNamespace

        /// <summary>
        /// 원본 네임스페이스
        /// </summary>
        [Browsable(true)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string OriginatingNamespace
        {
            get
            {
                return "ROOT\\CIMV2";
            }
        }
        
        #endregion
        #region 관리 클래스명 - ManagementClassName

        /// <summary>
        /// 관리 클래스명
        /// </summary>
        [Browsable(true)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string ManagementClassName
        {
            get
            {
                string result = _className;

                if(this.currentManagementBaseObject != null)
                {
                    if(this.currentManagementBaseObject.ClassPath != null)
                    {
                        result = (string)this.currentManagementBaseObject["__CLASS"];

                        if((result == null) || (result == string.Empty))
                        {
                            result = _className;
                        }
                    }
                }

                return result;
            }
        }
        
        #endregion
        #region 시스템 속성 - SystemProperties

        /// <summary>
        /// 시스템 속성
        /// </summary>
        [Browsable(true)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public ManagementSystemProperties SystemProperties
        {
            get
            {
                return this.managementSystemProperties;
            }
        }
        
        #endregion
        #region 마지막 바인딩 객체 - LateBoundObject

        /// <summary>
        /// 마지막 바인딩 객체
        /// </summary>
        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public ManagementBaseObject LateBoundObject
        {
            get
            {
                return this.currentManagementBaseObject;
            }
        }
        
        #endregion
        #region 범위 - Scope

        /// <summary>
        /// 범위
        /// </summary>
        [Browsable(true)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public ManagementScope Scope
        {
            get
            {
                if(this.isEmbedded == false)
                {
                    return this.managementObject.Scope;
                }
                else
                {
                    return null;
                }
            }
            set
            {
                if(this.isEmbedded == false)
                {
                    this.managementObject.Scope = value;
                }
            }
        }
        
        #endregion
        #region 자동 커밋 여부 - AutoCommit

        /// <summary>
        /// 자동 커밋 여부
        /// </summary>
        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public bool AutoCommit
        {
            get
            {
                return this.automaticCommit;
            }
            set
            {
                this.automaticCommit = value;
            }
        }
        
        #endregion
        #region 경로 - Path

        /// <summary>
        /// 경로
        /// </summary>
        [Browsable(true)]
        public ManagementPath Path
        {
            get
            {
                if(this.isEmbedded == false)
                {
                    return this.managementObject.Path;
                }
                else
                {
                    return null;
                }
            }
            set
            {
                if(this.isEmbedded == false)
                {
                    if(CheckIfProperClass(null, value, null) != true)
                    {
                        throw new ArgumentException("Class name does not match.");
                    }

                    this.managementObject.Path = value;
                }
            }
        }
        
        #endregion
        #region 정적 범위 - StaticScope

        /// <summary>
        /// 정적 범위
        /// </summary>
        [Browsable(true)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public static ManagementScope StaticScope
        {
            get
            {
                return _managementScope;
            }
            set
            {
                _managementScope = value;
            }
        }
        
        #endregion
        #region BIOS 특징 - BIOSCharacteristics

        /// <summary>
        /// BIOS 특징
        /// </summary>
        [Browsable(true)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        [Description("The BiosCharacteristics property identifies the BIOS characteristics supported by the system as defined by the System Management BIOS Reference Specification")]
        public BIOSCharacteristicsValue[] BIOSCharacteristics
        {
            get
            {
                Array array = (Array)this.currentManagementBaseObject["BiosCharacteristics"];

                BIOSCharacteristicsValue[] valueArray = new BIOSCharacteristicsValue[array.Length];

                int counter = 0;

                for(counter = 0; counter < array.Length; counter++)
                {
                    valueArray[counter] = (BIOSCharacteristicsValue)Convert.ToInt32(array.GetValue(counter));
                }

                return valueArray;
            }
        }
        
        #endregion
        #region BIOS 버전 - BIOSVersion

        /// <summary>
        /// BIOS 버전
        /// </summary>
        [Browsable(true)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        [Description("The BIOSVersion array property contains the complete System BIOS information. In many machines, there can be several version strings stored in the Registry representing the system BIOS info.  The property contains the complete set.")]
        public string[] BIOSVersion
        {
            get
            {
                return (string[])this.currentManagementBaseObject["BIOSVersion"];
            }
        }
        
        #endregion
        #region 빌드 번호 - BuildNumber 

        /// <summary>
        /// 빌드 번호
        /// </summary>
        [Browsable(true)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        [Description("The internal identifier for this compilation of this software element.")]
        public string BuildNumber
        {
            get
            {
                return (string)this.currentManagementBaseObject["BuildNumber"];
            }
        }
        
        #endregion
        #region 제목 - Caption

        /// <summary>
        /// 제목
        /// </summary>
        [Browsable(true)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        [Description("The Caption property is a short textual description (one-line string) of the object.")]
        public string Caption
        {
            get
            {
                return (string)this.currentManagementBaseObject["Caption"];
            }
        }
        
        #endregion
        #region 코드셋 - CodeSet

        /// <summary>
        /// 코드셋
        /// </summary>
        [Browsable(true)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        [Description("The code set used by this software element.")]
        public string CodeSet
        {
            get
            {
                return (string)this.currentManagementBaseObject["CodeSet"];
            }
        }
        
        #endregion
        #region 현재 언어 - CurrentLanguage

        /// <summary>
        /// 현재 언어
        /// </summary>
        [Browsable(true)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        [Description("The CurrentLanguage property shows the name of the current BIOS language.")]
        public string CurrentLanguage
        {
            get
            {
                return (string)this.currentManagementBaseObject["CurrentLanguage"];
            }
        }
        
        #endregion
        #region 설명 - Description

        /// <summary>
        /// 설명
        /// </summary>
        [Browsable(true)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        [Description("The Description property provides a textual description of the object.")]
        public string Description
        {
            get
            {
                return (string)this.currentManagementBaseObject["Description"];
            }
        }
        
        #endregion
        #region 식별 코드 - IdentificationCode

        /// <summary>
        /// 식별 코드
        /// </summary>
        [Browsable(true)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        [Description(" The value of this property is the manufacturer\'s identifier for this software element. Often this will be a stock keeping unit (SKU) or a part number.")]
        public string IdentificationCode
        {
            get
            {
                return (string)this.currentManagementBaseObject["IdentificationCode"];
            }
        }
        
        #endregion
        #region 설치 가능한 언어 NULL 여부 - IsInstallableLanguagesNull

        /// <summary>
        /// 설치 가능한 언어 NULL 여부
        /// </summary>
        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public bool IsInstallableLanguagesNull
        {
            get
            {
                if(this.currentManagementBaseObject["InstallableLanguages"] == null)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
        }
        
        #endregion
        #region 설치 가능한 언어 - InstallableLanguages

        /// <summary>
        /// 설치 가능한 언어
        /// </summary>
        [Browsable(true)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        [Description("The InstallableLanguages property indicates the number of languages available for installation on this system. Language may determine properties such as the need for Unicode and bi-directional text.")]
        [TypeConverter(typeof(WMIValueTypeConverter))]
        public ushort InstallableLanguages
        {
            get
            {
                if(this.currentManagementBaseObject["InstallableLanguages"] == null)
                {
                    return Convert.ToUInt16(0);
                }

                return (ushort)this.currentManagementBaseObject["InstallableLanguages"];
            }
        }
        
        #endregion
        #region 설치일 NULL 여부 - IsInstallDateNull

        /// <summary>
        /// 설치일 NULL 여부
        /// </summary>
        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public bool IsInstallDateNull
        {
            get
            {
                if(this.currentManagementBaseObject["InstallDate"] == null)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
        }
        
        #endregion
        #region 설치일 - InstallDate

        /// <summary>
        /// 설치일
        /// </summary>
        [Browsable(true)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        [Description("The InstallDate property is datetime value indicating when the object was installed. A lack of a value does not indicate that the object is not installed.")]
        [TypeConverter(typeof(WMIValueTypeConverter))]
        public DateTime InstallDate
        {
            get
            {
                if(this.currentManagementBaseObject["InstallDate"] != null)
                {
                    return ToDateTime((string)this.currentManagementBaseObject["InstallDate"]);
                }
                else
                {
                    return DateTime.MinValue;
                }
            }
        }
        
        #endregion
        #region 언어 에디션 - LanguageEdition

        /// <summary>
        /// 언어 에디션
        /// </summary>
        [Browsable(true)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        [Description("The value of this property identifies the language edition of this software element. The language codes defined in ISO 639 should be used. Where the software element represents multi-lingual or international version of a product, the string multilingual should be used.")]
        public string LanguageEdition
        {
            get
            {
                return (string)this.currentManagementBaseObject["LanguageEdition"];
            }
        }
        
        #endregion
        #region 언어 리스트 - LanguageList

        /// <summary>
        /// 언어 리스트
        /// </summary>
        [Browsable(true)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        [Description("The ListOfLanguages property contains a list of namesof available BIOS-installable languages.")]
        public string[] LanguageList
        {
            get
            {
                return (string[])this.currentManagementBaseObject["ListOfLanguages"];
            }
        }
        
        #endregion
        #region 제조자 - Manufacturer

        /// <summary>
        /// 제조자
        /// </summary>
        [Browsable(true)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        [Description("Manufacturer of this software element")]
        public string Manufacturer
        {
            get
            {
                return (string)this.currentManagementBaseObject["Manufacturer"];
            }
        }
        
        #endregion
        #region 명칭 - Name

        /// <summary>
        /// 명칭
        /// </summary>
        [Browsable(true)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        [Description("The name used to identify this software element")]
        public string Name
        {
            get
            {
                return (string)this.currentManagementBaseObject["Name"];
            }
        }
        
        #endregion
        #region 다른 타겟 운영 체제 - OtherTargetOS

        /// <summary>
        /// 다른 타겟 운영 체제
        /// </summary>
        [Browsable(true)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        [Description("The OtherTargetOS property records the manufacturer and  operating system type for a software element when  the TargetOperatingSystem property has a value of  1 (\"Other\").  Therefore, when the TargetOperatingSystem property has a value of \"Other\", the OtherTargetOS  property must have a non-null value.  For all other values  of TargetOperatingSystem, the OtherTargetOS property is to be NULL. ")]
        public string OtherTargetOS
        {
            get
            {
                return (string)this.currentManagementBaseObject["OtherTargetOS"];
            }
        }
        
        #endregion
        #region 메인 BIOS 여부 NULL 여부 - IsPrimaryBIOSNull

        /// <summary>
        /// 메인 BIOS 여부 NULL 여부
        /// </summary>
        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public bool IsPrimaryBIOSNull
        {
            get
            {
                if(this.currentManagementBaseObject["PrimaryBIOS"] == null)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
        }
        
        #endregion
        #region 메인 BIOS 여부 - PrimaryBIOS

        /// <summary>
        /// 메인 BIOS 여부
        /// </summary>
        [Browsable(true)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        [Description("If true, this is the primary BIOS of the computer system.")]
        [TypeConverter(typeof(WMIValueTypeConverter))]
        public bool PrimaryBIOS
        {
            get
            {
                if(this.currentManagementBaseObject["PrimaryBIOS"] == null)
                {
                    return Convert.ToBoolean(0);
                }

                return (bool)this.currentManagementBaseObject["PrimaryBIOS"];
            }
        }
        
        #endregion
        #region 배포일 NULL 여부 - IsReleaseDateNull

        /// <summary>
        /// 배포일 NULL 여부
        /// </summary>
        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public bool IsReleaseDateNull
        {
            get
            {
                if(this.currentManagementBaseObject["ReleaseDate"] == null)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
        }
        
        #endregion
        #region 배포일 - ReleaseDate

        /// <summary>
        /// 배포일
        /// </summary>
        [Browsable(true)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        [Description("The ReleaseDate property indicates the release date of the Win32 BIOS in the Coordinated Universal Time (UTC) format of YYYYMMDDHHMMSS.MMMMMM(+-)OOO.")]
        [TypeConverter(typeof(WMIValueTypeConverter))]
        public DateTime ReleaseDate
        {
            get
            {
                if(this.currentManagementBaseObject["ReleaseDate"] != null)
                {
                    return ToDateTime((string)this.currentManagementBaseObject["ReleaseDate"]);
                }
                else
                {
                    return DateTime.MinValue;
                }
            }
        }
        
        #endregion
        #region 시리얼 번호 - SerialNumber

        /// <summary>
        /// 시리얼 번호
        /// </summary>
        [Browsable(true)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        [Description("The assigned serial number of this software element.")]
        public string SerialNumber
        {
            get
            {
                return (string)this.currentManagementBaseObject["SerialNumber"];
            }
        }
        
        #endregion
        #region SMBIOS BIOS 버전 - SMBIOSBIOSVersion

        /// <summary>
        /// SMBIOS BIOS 버전
        /// </summary>
        [Browsable(true)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        [Description("The SMBIOSBIOSVersion property contains the BIOS version as reported by SMBIOS.")]
        public string SMBIOSBIOSVersion
        {
            get
            {
                return (string)this.currentManagementBaseObject["SMBIOSBIOSVersion"];
            }
        }
        
        #endregion
        #region SMBIOS 메이저 버전 NULL 여부 - IsSMBIOSMajorVersionNull

        /// <summary>
        /// SMBIOS 메이저 버전 NULL 여부
        /// </summary>
        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public bool IsSMBIOSMajorVersionNull
        {
            get
            {
                if(this.currentManagementBaseObject["SMBIOSMajorVersion"] == null)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
        }
        
        #endregion
        #region SMBIOS 메이저 버전 - SMBIOSMajorVersion

        /// <summary>
        /// SMBIOS 메이저 버전
        /// </summary>
        [Browsable(true)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        [Description("The SMBIOSMajorVersion property contains the major SMBIOS version number. This property will be NULL if SMBIOS not found.")]
        [TypeConverter(typeof(WMIValueTypeConverter))]
        public ushort SMBIOSMajorVersion
        {
            get
            {
                if(this.currentManagementBaseObject["SMBIOSMajorVersion"] == null)
                {
                    return Convert.ToUInt16(0);
                }

                return (ushort)this.currentManagementBaseObject["SMBIOSMajorVersion"];
            }
        }
        
        #endregion
        #region SMBIOS 마이너 버전 NULL 여부 - IsSMBIOSMinorVersionNull

        /// <summary>
        /// SMBIOS 마이너 버전 NULL 여부
        /// </summary>
        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public bool IsSMBIOSMinorVersionNull
        {
            get
            {
                if(this.currentManagementBaseObject["SMBIOSMinorVersion"] == null)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
        }
        
        #endregion
        #region SMBIOS 마이너 버전 - SMBIOSMinorVersion

        /// <summary>
        /// SMBIOS 마이너 버전
        /// </summary>
        [Browsable(true)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        [Description("The SMBIOSMinorVersion property contains the minor SMBIOS Version number. This property will be NULL if SMBIOS not found.")]
        [TypeConverter(typeof(WMIValueTypeConverter))]
        public ushort SMBIOSMinorVersion
        {
            get
            {
                if(this.currentManagementBaseObject["SMBIOSMinorVersion"] == null)
                {
                    return Convert.ToUInt16(0);
                }

                return (ushort)this.currentManagementBaseObject["SMBIOSMinorVersion"];
            }
        }
        
        #endregion
        #region SMBIOS 표시 여부 NULL 여부 - IsSMBIOSPresentNull

        /// <summary>
        /// SMBIOS 표시 여부 NULL 여부
        /// </summary>
        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public bool IsSMBIOSPresentNull
        {
            get
            {
                if(this.currentManagementBaseObject["SMBIOSPresent"] == null)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
        }
        
        #endregion
        #region SMBIOS 표시 여부 - SMBIOSPresent

        /// <summary>
        /// SMBIOS 표시 여부
        /// </summary>
        [Browsable(true)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        [Description("The SMBIOSPresent property indicates whether the SMBIOS is available on this computer system.\nValues : TRUE or FALSE. If TRUE, SMBIOS is on this computer.")]
        [TypeConverter(typeof(WMIValueTypeConverter))]
        public bool SMBIOSPresent
        {
            get
            {
                if(this.currentManagementBaseObject["SMBIOSPresent"] == null)
                {
                    return Convert.ToBoolean(0);
                }

                return (bool)this.currentManagementBaseObject["SMBIOSPresent"];
            }
        }
        
        #endregion
        #region 소프트웨어 요소 ID - SoftwareElementID

        /// <summary>
        /// 소프트웨어 요소 ID
        /// </summary>
        [Browsable(true)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        [Description("This is an identifier for this software element and is designed to be used in conjunction with other keys to create a unique representation  of this CIM_SoftwareElement")]
        public string SoftwareElementID
        {
            get
            {
                return (string)this.currentManagementBaseObject["SoftwareElementID"];
            }
        }
        
        #endregion
        #region 소프트웨어 요소 상태 NULL 여부 - IsSoftwareElementStateNull

        /// <summary>
        /// 소프트웨어 요소 상태 NULL 여부
        /// </summary>
        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public bool IsSoftwareElementStateNull
        {
            get
            {
                if(this.currentManagementBaseObject["SoftwareElementState"] == null)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
        }
        
        #endregion
        #region 소프트웨어 요소 상태 - SoftwareElementState

        /// <summary>
        /// 소프트웨어 요소 상태
        /// </summary>
        [Browsable(true)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        [Description("The SoftwareElementState is defined in this model to  identify various states of a software elements life cycle. - A software element in the deployable state describes     the details necessary to successful distribute it and     the details (conditions and actions) required to create     a software element in the installable state (i.e., the next state).  - A software element in the installable state describes     the details necessary to successfully install it and the    details (conditions and actions required to create a     software element in the executable state (i.e., the next state).  - A software element in the executable state describes the     details necessary to successfully  start it and the details     (conditions and actions required to create a software element in     the running state (i.e., the next state).  - A software element in the running state describes the details necessary to monitor and operate on a start element.")]
        [TypeConverter(typeof(WMIValueTypeConverter))]
        public ushort SoftwareElementState
        {
            get
            {
                if(this.currentManagementBaseObject["SoftwareElementState"] == null)
                {
                    return Convert.ToUInt16(0);
                }

                return (ushort)this.currentManagementBaseObject["SoftwareElementState"];
            }
        }
        
        #endregion
        #region 상태 - Status

        /// <summary>
        /// 상태
        /// </summary>
        [Browsable(true)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        [Description("The Status property is a string indicating the current status of the object. Various operational and non-operational statuses can be defined. Operational statuses are \"OK\", \"Degraded\" and \"Pred Fail\". \"Pred Fail\" indicates that an element may be functioning properly but predicting a failure in the near future. An example is a SMART-enabled hard drive. Non-operational statuses can also be specified. These are \"Error\", \"Starting\", \"Stopping\" and \"Service\". The latter, \"Service\", could apply during mirror-resilvering of a disk, reload of a user permissions list, or other administrative work. Not all such work is on-line, yet the managed element is neither \"OK\" nor in one of the other states.")]
        public string Status
        {
            get
            {
                return (string)this.currentManagementBaseObject["Status"];
            }
        }
        
        #endregion
        #region 타겟 운영 체제 NULL 여부 - IsTargetOperatingSystemNull

        /// <summary>
        /// 타겟 운영 체제 NULL 여부
        /// </summary>
        [Browsable(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public bool IsTargetOperatingSystemNull
        {
            get
            {
                if(this.currentManagementBaseObject["TargetOperatingSystem"] == null)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
        }
        
        #endregion
        #region 타겟 운영 체제 - TargetOperatingSystem

        /// <summary>
        /// 타겟 운영 체제
        /// </summary>
        [Browsable(true)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        [Description("The TargetOperatingSystem property allows the provider to specify the  operating system environment. The value of this property does not  ensure binary executable.  Two other pieces of information are needed.   First, the version of the OS needs to be specified using the OS  version check. The second piece of information is the architecture the  OS runs on. The combination of these constructs allows the provider to  clearly identify the level of OS required for a particular software  element.")]
        [TypeConverter(typeof(WMIValueTypeConverter))]
        public ushort TargetOperatingSystem
        {
            get
            {
                if(this.currentManagementBaseObject["TargetOperatingSystem"] == null)
                {
                    return Convert.ToUInt16(0);
                }

                return (ushort)this.currentManagementBaseObject["TargetOperatingSystem"];
            }
        }
        
        #endregion
        #region 버전 - Version

        /// <summary>
        /// 버전
        /// </summary>
        [Browsable(true)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        [Description("The Version property contains the version of the BIOS. This string is created by the BIOS manufacturer.")]
        public string Version
        {
            get
            {
                return (string)this.currentManagementBaseObject["Version"];
            }
        }

        #endregion

        //////////////////////////////////////////////////////////////////////////////////////////////////// Consturctor
        ////////////////////////////////////////////////////////////////////////////////////////// Public

        #region 생성자 - BIOS()

        /// <summary>
        /// 생성자
        /// </summary>
        public BIOS()
        {
            InitializeObject(null, null, null);
        }

        #endregion
        #region 생성자 - BIOS(keyName, keySoftwareElementID, keySoftwareElementState, keyTargetOperatingSystem, keyVersion)

        /// <summary>
        /// 생성자
        /// </summary>
        /// <param name="keyName">키명</param>
        /// <param name="keySoftwareElementID">키 소프트웨어 요소 ID</param>
        /// <param name="keySoftwareElementState">키 소프트웨어 요소 상태</param>
        /// <param name="keyTargetOperatingSystem">키 타겟 운영 체제</param>
        /// <param name="keyVersion">키 버전</param>
        public BIOS(string keyName, string keySoftwareElementID, ushort keySoftwareElementState, ushort keyTargetOperatingSystem, string keyVersion)
        {
            InitializeObject(null, new ManagementPath(BIOS.ConstructPath(keyName, keySoftwareElementID, keySoftwareElementState, keyTargetOperatingSystem, keyVersion)), null);
        }

        #endregion
        #region 생성자 - BIOS(managementScope, keyName, keySoftwareElementID, keySoftwareElementState, keyTargetOperatingSystem, keyVersion)

        /// <summary>
        /// 생성자
        /// </summary>
        /// <param name="managementScope">관리 범위</param>
        /// <param name="keyName">키명</param>
        /// <param name="keySoftwareElementID">키 소프트웨어 요소 ID</param>
        /// <param name="keySoftwareElementState">키 소프트웨어 요소 상태</param>
        /// <param name="keyTargetOperatingSystem">키 타겟 운영 체제</param>
        /// <param name="keyVersion">키 버전</param>
        public BIOS(ManagementScope managementScope, string keyName, string keySoftwareElementID, ushort keySoftwareElementState, ushort keyTargetOperatingSystem, string keyVersion)
        {
            InitializeObject((ManagementScope)managementScope, new ManagementPath(BIOS.ConstructPath(keyName, keySoftwareElementID, keySoftwareElementState, keyTargetOperatingSystem, keyVersion)), null);
        }

        #endregion
        #region 생성자 - BIOS(managementScope, managementPath)

        /// <summary>
        /// 생성자
        /// </summary>
        /// <param name="managementScope">관리 범위</param>
        /// <param name="managementPath">관리 경로</param>
        public BIOS(ManagementScope managementScope, ManagementPath managementPath)
        {
            InitializeObject(managementScope, managementPath, null);
        }

        #endregion
        #region 생성자 - BIOS(managementPath, objectGetOptions)

        /// <summary>
        /// 생성자
        /// </summary>
        /// <param name="managementPath">관리 경로</param>
        /// <param name="objectGetOptions">객체 GET 옵션</param>
        public BIOS(ManagementPath managementPath, ObjectGetOptions objectGetOptions)
        {
            InitializeObject(null, managementPath, objectGetOptions);
        }

        #endregion
        #region 생성자 - BIOS(managementPath)

        /// <summary>
        /// 생성자
        /// </summary>
        /// <param name="managementPath">관리 경로</param>
        public BIOS(ManagementPath managementPath)
        {
            InitializeObject(null, managementPath, null);
        }

        #endregion
        #region 생성자 - BIOS(managementScope, managementPath, objectGetOptions)

        /// <summary>
        /// 생성자
        /// </summary>
        /// <param name="managementScope">관리 범위</param>
        /// <param name="managementPath">관리 경로</param>
        /// <param name="objectGetOptions">객체 GET 옵션</param>
        public BIOS(ManagementScope managementScope, ManagementPath managementPath, ObjectGetOptions objectGetOptions)
        {
            InitializeObject(managementScope, managementPath, objectGetOptions);
        }

        #endregion
        #region 생성자 - BIOS(managementObject)

        /// <summary>
        /// 생성자
        /// </summary>
        /// <param name="managementObject">관리 객체</param>
        public BIOS(ManagementObject managementObject)
        {
            Initialize();

            if(CheckIfProperClass(managementObject) == true)
            {
                this.managementObject = managementObject;

                this.managementSystemProperties = new ManagementSystemProperties(this.managementObject);

                this.currentManagementBaseObject = this.managementObject;
            }
            else
            {
                throw new ArgumentException("Class name does not match.");
            }
        }

        #endregion
        #region 생성자 - BIOS(managementBaseObject)

        /// <summary>
        /// 생성자
        /// </summary>
        /// <param name="managementBaseObject">관리 기본 객체</param>
        public BIOS(ManagementBaseObject managementBaseObject)
        {
            Initialize();

            if(CheckIfProperClass(managementBaseObject) == true)
            {
                this.embeddedManagementBaseObject = managementBaseObject;

                this.managementSystemProperties = new ManagementSystemProperties(managementBaseObject);

                this.currentManagementBaseObject = this.embeddedManagementBaseObject;

                this.isEmbedded = true;
            }
            else
            {
                throw new ArgumentException("Class name does not match.");
            }
        }

        #endregion

        //////////////////////////////////////////////////////////////////////////////////////////////////// Method
        ////////////////////////////////////////////////////////////////////////////////////////// Static
        //////////////////////////////////////////////////////////////////////////////// Public

        #region 인스턴스 컬렉션 구하기 - GetInstances()

        /// <summary>
        /// 인스턴스 컬렉션 구하기
        /// </summary>
        /// <returns>BIOS 컬렉션</returns>
        public static BIOSCollection GetInstances()
        {
            return GetInstances(null, null, null);
        }

        #endregion
        #region 인스턴스 컬렉션 구하기 - GetInstances(condition)

        /// <summary>
        /// 인스턴스 컬렉션 구하기
        /// </summary>
        /// <param name="condition">조건</param>
        /// <returns>BIOS 컬렉션</returns>
        public static BIOSCollection GetInstances(string condition)
        {
            return GetInstances(null, condition, null);
        }

        #endregion
        #region 인스턴스 컬렉션 구하기 - GetInstances(selectedPropertyArray)

        /// <summary>
        /// 인스턴스 컬렉션 구하기
        /// </summary>
        /// <param name="selectedPropertyArray">선택 속성 배열</param>
        /// <returns>BIOS 컬렉션</returns>
        public static BIOSCollection GetInstances(string[] selectedPropertyArray)
        {
            return GetInstances(null, null, selectedPropertyArray);
        }

        #endregion
        #region 인스턴스 컬렉션 구하기 - GetInstances(condition, selectedPropertyArray)

        /// <summary>
        /// 인스턴스 컬렉션 구하기
        /// </summary>
        /// <param name="condition">조건</param>
        /// <param name="selectedPropertyArray">선택 속성 배열</param>
        /// <returns>BIOS 컬렉션</returns>
        public static BIOSCollection GetInstances(string condition, string[] selectedPropertyArray)
        {
            return GetInstances(null, condition, selectedPropertyArray);
        }

        #endregion
        #region 인스턴스 컬렉션 구하기 - GetInstances(managementScope, enumerationOptions)

        /// <summary>
        /// 인스턴스 컬렉션 구하기
        /// </summary>
        /// <param name="managementScope">관리 범위</param>
        /// <param name="enumerationOptions">열거형 조건</param>
        /// <returns>BIOS 컬렉션</returns>
        public static BIOSCollection GetInstances(ManagementScope managementScope, EnumerationOptions enumerationOptions)
        {
            if(managementScope == null)
            {
                if(_managementScope == null)
                {
                    managementScope = new ManagementScope();

                    managementScope.Path.NamespacePath = "root\\CIMV2";
                }
                else
                {
                    managementScope = _managementScope;
                }
            }

            ManagementPath managementPath = new ManagementPath();

            managementPath.ClassName     = "Win32_BIOS";
            managementPath.NamespacePath = "root\\CIMV2";

            ManagementClass managementClass = new ManagementClass(managementScope, managementPath, null);

            if(enumerationOptions == null)
            {
                enumerationOptions = new EnumerationOptions();

                enumerationOptions.EnsureLocatable = true;
            }

            return new BIOSCollection(managementClass.GetInstances(enumerationOptions));
        }

        #endregion
        #region 인스턴스 컬렉션 구하기 - GetInstances(managementScope, condition)

        /// <summary>
        /// 인스턴스 컬렉션 구하기
        /// </summary>
        /// <param name="managementScope">관리 범위</param>
        /// <param name="condition">조건</param>
        /// <returns>BIOS 컬렉션</returns>
        public static BIOSCollection GetInstances(ManagementScope managementScope, string condition)
        {
            return GetInstances(managementScope, condition, null);
        }

        #endregion
        #region 인스턴스 컬렉션 구하기 - GetInstances(managementScope, selectedPropertyArray)

        /// <summary>
        /// 인스턴스 컬렉션 구하기
        /// </summary>
        /// <param name="managementScope">관리 범위</param>
        /// <param name="selectedPropertyArray">선택 속성 배열</param>
        /// <returns>BIOS 컬렉션</returns>
        public static BIOSCollection GetInstances(ManagementScope managementScope, string[] selectedPropertyArray)
        {
            return GetInstances(managementScope, null, selectedPropertyArray);
        }

        #endregion
        #region 인스턴스 컬렉션 구하기 - GetInstances(managementScope, condition, selectedPropertyArray)

        /// <summary>
        /// 인스턴스 컬렉션 구하기
        /// </summary>
        /// <param name="managementScope">관리 범위</param>
        /// <param name="condition">조건</param>
        /// <param name="selectedPropertyArray">선택 속성 배열</param>
        /// <returns>BIOS 컬렉션</returns>
        public static BIOSCollection GetInstances(ManagementScope managementScope, string condition, string[] selectedPropertyArray)
        {
            if(managementScope == null)
            {
                if(_managementScope == null)
                {
                    managementScope = new ManagementScope();

                    managementScope.Path.NamespacePath = "root\\CIMV2";
                }
                else
                {
                    managementScope = _managementScope;
                }
            }

            ManagementObjectSearcher managementObjectSearcher = new ManagementObjectSearcher(managementScope, new SelectQuery("Win32_BIOS", condition, selectedPropertyArray));

            EnumerationOptions enumerationOptions = new EnumerationOptions();

            enumerationOptions.EnsureLocatable = true;

            managementObjectSearcher.Options = enumerationOptions;

            return new BIOSCollection(managementObjectSearcher.Get());
        }

        #endregion

        #region 인스턴스 생성하기 - CreateInstance()

        /// <summary>
        /// 인스턴스 생성하기
        /// </summary>
        /// <returns>BIOS</returns>
        [Browsable(true)]
        public static BIOS CreateInstance()
        {
            ManagementScope managementScope = null;

            if(_managementScope == null)
            {
                managementScope = new ManagementScope();

                managementScope.Path.NamespacePath = _wmiNamespace;
            }
            else
            {
                managementScope = _managementScope;
            }

            ManagementPath managementPath = new ManagementPath(_className);

            ManagementClass managementClass = new ManagementClass(managementScope, managementPath, null);

            return new BIOS(managementClass.CreateInstance());
        }

        #endregion

        //////////////////////////////////////////////////////////////////////////////// Private

        #region 날짜/시간 구하기 - ToDateTime(dmtfDate)

        /// <summary>
        /// 날짜/시간 구하기
        /// </summary>
        /// <param name="dmtfDate">DMTF 일자</param>
        /// <returns>날짜/시간</returns>
        private static DateTime ToDateTime(string dmtfDate)
        {
            DateTime initializer = DateTime.MinValue;

            int    year      = initializer.Year;
            int    month     = initializer.Month;
            int    day       = initializer.Day;
            int    hour      = initializer.Hour;
            int    minute    = initializer.Minute;
            int    second    = initializer.Second;
            long   tickCount = 0;
            string dmtf      = dmtfDate;

            DateTime dateTime = DateTime.MinValue;

            string temporaryString = string.Empty;

            if(dmtf == null)
            {
                throw new ArgumentOutOfRangeException();
            }

            if(dmtf.Length == 0)
            {
                throw new ArgumentOutOfRangeException();
            }

            if(dmtf.Length != 25)
            {
                throw new ArgumentOutOfRangeException();
            }

            try
            {
                temporaryString = dmtf.Substring(0, 4);

                if("****" != temporaryString)
                {
                    year = int.Parse(temporaryString);
                }

                temporaryString = dmtf.Substring(4, 2);

                if("**" != temporaryString)
                {
                    month = int.Parse(temporaryString);
                }

                temporaryString = dmtf.Substring(6, 2);

                if("**" != temporaryString)
                {
                    day = int.Parse(temporaryString);
                }
 
                temporaryString = dmtf.Substring(8, 2);

                if("**" != temporaryString)
                {
                    hour = int.Parse(temporaryString);
                }

                temporaryString = dmtf.Substring(10, 2);

                if("**" != temporaryString)
                {
                    minute = int.Parse(temporaryString);
                }

                temporaryString = dmtf.Substring(12, 2);

                if("**" != temporaryString)
                {
                    second = int.Parse(temporaryString);
                }

                temporaryString = dmtf.Substring(15, 6);

                if("******" != temporaryString)
                {
                    tickCount = long.Parse(temporaryString) * (long)(TimeSpan.TicksPerMillisecond / 1000);
                }

                if((year < 0) || (month < 0) || (day < 0) || (hour < 0) || (minute < 0) || (minute < 0) || (second < 0) || (tickCount < 0))
                {
                    throw new ArgumentOutOfRangeException();
                }
            }
            catch(Exception e)
            {
                throw new ArgumentOutOfRangeException(null, e.Message);
            }

            dateTime = new DateTime(year, month, day, hour, minute, second, 0);

            dateTime = dateTime.AddTicks(tickCount);

            TimeSpan tickOffset = TimeZone.CurrentTimeZone.GetUtcOffset(dateTime);

            int  utcOffset          = 0;
            int  offsetToBeAdjusted = 0;
            long OffsetMinuteCount  = (long)(tickOffset.Ticks / TimeSpan.TicksPerMinute);

            temporaryString = dmtf.Substring(22, 3);

            if(temporaryString != "******")
            {
                temporaryString = dmtf.Substring(21, 4);

                try
                {
                    utcOffset = int.Parse(temporaryString);
                }
                catch(Exception e)
                {
                    throw new ArgumentOutOfRangeException(null, e.Message);
                }

                offsetToBeAdjusted = (int)(OffsetMinuteCount - utcOffset);
                dateTime           = dateTime.AddMinutes((double)offsetToBeAdjusted);
            }

            return dateTime;
        }

        #endregion
        #region DMTF 날짜/시간 구하기 - ToDMTFDateTime(dateTime)

        /// <summary>
        /// DMTF 날짜/시간 구하기
        /// </summary>
        /// <param name="dateTime">날짜/시간</param>
        /// <returns>DMTF 날짜/시간</returns>
        private static string ToDMTFDateTime(DateTime dateTime)
        {
            string utcString = string.Empty;

            TimeSpan tickOffset = TimeZone.CurrentTimeZone.GetUtcOffset(dateTime);

            long OffsetMinuteCount = (long)(tickOffset.Ticks / TimeSpan.TicksPerMinute);

            if(Math.Abs(OffsetMinuteCount) > 999)
            {
                dateTime = dateTime.ToUniversalTime();

                utcString = "+000";
            }
            else
            {
                if(tickOffset.Ticks >= 0)
                {
                    utcString = string.Concat("+", ((long)(tickOffset.Ticks / TimeSpan.TicksPerMinute)).ToString().PadLeft(3, '0'));
                }
                else
                {
                    string strTemporary = ((long)OffsetMinuteCount).ToString();

                    utcString = string.Concat("-", strTemporary.Substring(1, strTemporary.Length - 1).PadLeft(3, '0'));
                }
            }

            string dmtfDateTime = ((int)dateTime.Year).ToString().PadLeft(4, '0');

            dmtfDateTime = string.Concat(dmtfDateTime, ((int)dateTime.Month ).ToString().PadLeft(2, '0'));
            dmtfDateTime = string.Concat(dmtfDateTime, ((int)dateTime.Day   ).ToString().PadLeft(2, '0'));
            dmtfDateTime = string.Concat(dmtfDateTime, ((int)dateTime.Hour  ).ToString().PadLeft(2, '0'));
            dmtfDateTime = string.Concat(dmtfDateTime, ((int)dateTime.Minute).ToString().PadLeft(2, '0'));
            dmtfDateTime = string.Concat(dmtfDateTime, ((int)dateTime.Second).ToString().PadLeft(2, '0'));
            dmtfDateTime = string.Concat(dmtfDateTime, ".");

            DateTime temporaryDateTime = new DateTime(dateTime.Year, dateTime.Month, dateTime.Day, dateTime.Hour, dateTime.Minute, dateTime.Second, 0);

            long microSecondCount = (long)(((dateTime.Ticks - temporaryDateTime.Ticks) * 1000) / TimeSpan.TicksPerMillisecond);

            string microSecondString = ((long)microSecondCount).ToString();

            if(microSecondString.Length > 6)
            {
                microSecondString = microSecondString.Substring(0, 6);
            }

            dmtfDateTime = string.Concat(dmtfDateTime, microSecondString.PadLeft(6, '0'));
            dmtfDateTime = string.Concat(dmtfDateTime, utcString);

            return dmtfDateTime;
        }

        #endregion

        #region 경로 구축하기 - ConstructPath(keyName, keySoftwareElementID, keySoftwareElementState, keyTargetOperatingSystem, keyVersion)

        /// <summary>
        /// 경로 구축하기
        /// </summary>
        /// <param name="keyName">키명</param>
        /// <param name="keySoftwareElementID">키 소프트웨어 요소 ID</param>
        /// <param name="keySoftwareElementState">키 소프트웨어 요소 상태</param>
        /// <param name="keyTargetOperatingSystem">키 타겟 운영 체제</param>
        /// <param name="keyVersion">키 버전</param>
        /// <returns>경로</returns>
        private static string ConstructPath(string keyName, string keySoftwareElementID, ushort keySoftwareElementState, ushort keyTargetOperatingSystem, string keyVersion)
        {
            string path = "ROOT\\CIMV2:Win32_BIOS";

            path = string.Concat(path, string.Concat(".Name="                 , string.Concat("\"", string.Concat(keyName, "\""))));
            path = string.Concat(path, string.Concat(",SoftwareElementID="    , string.Concat("\"", string.Concat(keySoftwareElementID, "\""))));
            path = string.Concat(path, string.Concat(",SoftwareElementState=" , ((ushort)keySoftwareElementState).ToString()));
            path = string.Concat(path, string.Concat(",TargetOperatingSystem=", ((ushort)keyTargetOperatingSystem).ToString()));
            path = string.Concat(path, string.Concat(",Version="              , string.Concat("\"", string.Concat(keyVersion, "\""))));
            return path;
        }

        #endregion

        ////////////////////////////////////////////////////////////////////////////////////////// Instance
        //////////////////////////////////////////////////////////////////////////////// Public

        #region 객체 커밋하기 - CommitObject()

        /// <summary>
        /// 객체 커밋하기
        /// </summary>
        [Browsable(true)]
        public void CommitObject()
        {
            if(this.isEmbedded == false)
            {
                this.managementObject.Put();
            }
        }
        
        #endregion
        #region 객체 커밋하기 - CommitObject(putOptions)

        /// <summary>
        /// 객체 커밋하기
        /// </summary>
        /// <param name="putOptions">PUT 조건</param>
        [Browsable(true)]
        public void CommitObject(PutOptions putOptions)
        {
            if(this.isEmbedded == false)
            {
                this.managementObject.Put(putOptions);
            }
        }

        #endregion

        #region 삭제하기 - Delete()

        /// <summary>
        /// 삭제하기
        /// </summary>
        [Browsable(true)]
        public void Delete()
        {
            this.managementObject.Delete();
        }

        #endregion

        //////////////////////////////////////////////////////////////////////////////// Private
        
        #region 적절한 클래스 여부 체크하기 - CheckIfProperClass(managementBaseObject)

        /// <summary>
        /// 적절한 클래스 여부 체크하기
        /// </summary>
        /// <param name="managementBaseObject">관리 기본 객체</param>
        /// <returns>적절한 클래스 여부</returns>
        private bool CheckIfProperClass(ManagementBaseObject managementBaseObject)
        {
            if((managementBaseObject != null)  && (string.Compare(((string)(managementBaseObject["__CLASS"])), this.ManagementClassName, true, CultureInfo.InvariantCulture) == 0))
            {
                return true;
            }
            else
            {
                Array parentClassArray = (Array)(managementBaseObject["__DERIVATION"]);

                if(parentClassArray != null)
                {
                    int count = 0;

                    for(count = 0; count < parentClassArray.Length; count++)
                    {
                        if(string.Compare((string)(parentClassArray.GetValue(count)), this.ManagementClassName, true, CultureInfo.InvariantCulture) == 0)
                        {
                            return true;
                        }
                    }
                }
            }

            return false;
        }

        #endregion
        #region 적절한 클래스 여부 체크하기 - CheckIfProperClass(managementScope, managementPath, objectGetOptions)

        /// <summary>
        /// 적절한 클래스 여부 체크하기
        /// </summary>
        /// <param name="managementScope">관리 범위</param>
        /// <param name="managementPath">관리 경로</param>
        /// <param name="objectGetOptions">객체 GET 옵션</param>
        /// <returns>적절한 클래스 여부</returns>
        private bool CheckIfProperClass(ManagementScope managementScope, ManagementPath managementPath, ObjectGetOptions objectGetOptions)
        {
            if((managementPath != null) && (string.Compare(managementPath.ClassName, this.ManagementClassName, true, CultureInfo.InvariantCulture) == 0))
            {
                return true;
            }
            else
            {
                return CheckIfProperClass(new ManagementObject(managementScope, managementPath, objectGetOptions));
            }
        }

        #endregion

        #region 설치 가능한 언어 직렬화 여부 구하기 - ShouldSerializeInstallableLanguages()

        /// <summary>
        /// 설치 가능한 언어 직렬화 여부 구하기
        /// </summary>
        /// <returns>설치 가능한 언어 직렬화 여부</returns>
        private bool ShouldSerializeInstallableLanguages()
        {
            if(this.IsInstallableLanguagesNull == false)
            {
                return true;
            }

            return false;
        }

        #endregion
        #region 설치일 직렬화 여부 구하기 - ShouldSerializeInstallDate()

        /// <summary>
        /// 설치일 직렬화 여부 구하기
        /// </summary>
        /// <returns>설치일 직렬화 여부</returns>
        private bool ShouldSerializeInstallDate()
        {
            if(this.IsInstallDateNull == false)
            {
                return true;
            }

            return false;
        }
        
        #endregion
        #region 메인 BIOS 직렬화 여부 구하기 - ShouldSerializePrimaryBIOS()

        /// <summary>
        /// 메인 BIOS 직렬화 여부 구하기
        /// </summary>
        /// <returns>메인 BIOS 직렬화 여부</returns>
        private bool ShouldSerializePrimaryBIOS()
        {
            if(this.IsPrimaryBIOSNull == false)
            {
                return true;
            }

            return false;
        }
        
        #endregion
        #region 배포일 직렬화 여부 구하기 - ShouldSerializeReleaseDate()

        /// <summary>
        /// 배포일 직렬화 여부 구하기
        /// </summary>
        /// <returns>배포일 직렬화 여부</returns>
        private bool ShouldSerializeReleaseDate()
        {
            if(this.IsReleaseDateNull == false)
            {
                return true;
            }

            return false;
        }
        
        #endregion
        #region SMBIOS 메이저 버전 직렬화 여부 구하기 - ShouldSerializeSMBIOSMajorVersion()

        /// <summary>
        /// SMBIOS 메이저 버전 직렬화 여부 구하기
        /// </summary>
        /// <returns>SMBIOS 메이저 버전 직렬화 여부</returns>
        private bool ShouldSerializeSMBIOSMajorVersion()
        {
            if(this.IsSMBIOSMajorVersionNull == false)
            {
                return true;
            }

            return false;
        }
        
        #endregion
        #region SMBIOS 마이너 버전 직렬화 여부 구하기 - ShouldSerializeSMBIOSMinorVersion()

        /// <summary>
        /// SMBIOS 마이너 버전 직렬화 여부 구하기
        /// </summary>
        /// <returns>SMBIOS 마이너 버전 직렬화 여부</returns>
        private bool ShouldSerializeSMBIOSMinorVersion()
        {
            if(this.IsSMBIOSMinorVersionNull == false)
            {
                return true;
            }

            return false;
        }
        
        #endregion
        #region SMBIOS 표시 직렬화 여부 구하기 - ShouldSerializeSMBIOSPresent()

        /// <summary>
        /// SMBIOS 표시 직렬화 여부 구하기
        /// </summary>
        /// <returns>SMBIOS 표시 직렬화 여부</returns>
        private bool ShouldSerializeSMBIOSPresent()
        {
            if(this.IsSMBIOSPresentNull == false)
            {
                return true;
            }

            return false;
        }
        
        #endregion
        #region 소프트웨어 요소 상태 직렬화 여부 구하기 - ShouldSerializeSoftwareElementState()

        /// <summary>
        /// 소프트웨어 요소 상태 직렬화 여부 구하기
        /// </summary>
        /// <returns>소프트웨어 요소 상태 직렬화 여부</returns>
        private bool ShouldSerializeSoftwareElementState()
        {
            if(this.IsSoftwareElementStateNull == false)
            {
                return true;
            }

            return false;
        }
        
        #endregion
        #region 타겟 운영 체제 직렬화 구하기 - ShouldSerializeTargetOperatingSystem()

        /// <summary>
        /// 타겟 운영 체제 직렬화 구하기
        /// </summary>
        /// <returns>타겟 운영 체제 직렬화</returns>
        private bool ShouldSerializeTargetOperatingSystem()
        {
            if(this.IsTargetOperatingSystemNull == false)
            {
                return true;
            }

            return false;
        }

        #endregion

        #region 초기화하기 - Initialize()

        /// <summary>
        /// 초기화하기
        /// </summary>
        private void Initialize()
        {
            this.automaticCommit = true;

            this.isEmbedded = false;
        }

        #endregion
        #region 객체 초기화하기 - InitializeObject(managementScope, managementPath, objectGetOptions)

        /// <summary>
        /// 객체 초기화하기
        /// </summary>
        /// <param name="managementScope">관리 범위</param>
        /// <param name="managementPath">관리 경로</param>
        /// <param name="objectGetOptions">객체 GET 조건</param>
        private void InitializeObject(ManagementScope managementScope, ManagementPath managementPath, ObjectGetOptions objectGetOptions)
        {
            Initialize();

            if(managementPath != null)
            {
                if(CheckIfProperClass(managementScope, managementPath, objectGetOptions) != true)
                {
                    throw new ArgumentException("Class name does not match.");
                }
            }

            this.managementObject = new ManagementObject(managementScope, managementPath, objectGetOptions);

            this.managementSystemProperties = new ManagementSystemProperties(this.managementObject);

            this.currentManagementBaseObject = this.managementObject;
        }

        #endregion
    }
}
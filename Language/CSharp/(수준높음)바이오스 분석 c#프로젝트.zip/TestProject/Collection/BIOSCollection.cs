﻿using System;
using System.Collections;
using System.Management;

namespace TestProject
{
    /// <summary>
    /// BIOS 컬렉션
    /// </summary>
    public class BIOSCollection : object, ICollection
    {
        //////////////////////////////////////////////////////////////////////////////////////////////////// Class
        ////////////////////////////////////////////////////////////////////////////////////////// Public

        #region BIOS 열거자 - BIOSEnumerator

        /// <summary>
        /// BIOS 열거자
        /// </summary>
        public class BIOSEnumerator : object, IEnumerator
        {
            //////////////////////////////////////////////////////////////////////////////////////////////////// Field
            ////////////////////////////////////////////////////////////////////////////////////////// Private

            #region Field

            /// <summary>
            /// 관리 객체 열거자
            /// </summary>
            private ManagementObjectCollection.ManagementObjectEnumerator managementObjectEnumerator;

            #endregion

            //////////////////////////////////////////////////////////////////////////////////////////////////// Property
            ////////////////////////////////////////////////////////////////////////////////////////// Public

            #region 현재 항목 - Current

            /// <summary>
            /// 현재 항목
            /// </summary>
            public virtual object Current
            {
                get
                {
                    return new BIOS((ManagementObject)this.managementObjectEnumerator.Current);
                }
            }

            #endregion

            //////////////////////////////////////////////////////////////////////////////////////////////////// Constructor
            ////////////////////////////////////////////////////////////////////////////////////////// Public

            #region 생성자 - BIOSEnumerator(managementObjectEnumerator)

            /// <summary>
            /// 생성자
            /// </summary>
            /// <param name="managementObjectEnumerator">관리 객체 열거자</param>
            public BIOSEnumerator(ManagementObjectCollection.ManagementObjectEnumerator managementObjectEnumerator)
            {
                this.managementObjectEnumerator = managementObjectEnumerator;
            }

            #endregion

            //////////////////////////////////////////////////////////////////////////////////////////////////// Method
            ////////////////////////////////////////////////////////////////////////////////////////// Public

            #region 다음으로 이동하기 - MoveNext()

            /// <summary>
            /// 다음으로 이동하기
            /// </summary>
            /// <returns>처리 결과</returns>
            public virtual bool MoveNext()
            {
                return this.managementObjectEnumerator.MoveNext();
            }

            #endregion
            #region 리셋하기 - Reset()

            /// <summary>
            /// 리셋하기
            /// </summary>
            public virtual void Reset()
            {
                this.managementObjectEnumerator.Reset();
            }

            #endregion
        }

        #endregion

        //////////////////////////////////////////////////////////////////////////////////////////////////// Field
        ////////////////////////////////////////////////////////////////////////////////////////// Private

        #region Field

        /// <summary>
        /// 관리 객체 컬렉션
        /// </summary>
        private ManagementObjectCollection managementObjectCollection;

        #endregion

        //////////////////////////////////////////////////////////////////////////////////////////////////// Property
        ////////////////////////////////////////////////////////////////////////////////////////// Public

        #region 카운트 - Count

        /// <summary>
        /// 카운트
        /// </summary>
        public virtual int Count
        {
            get
            {
                return this.managementObjectCollection.Count;
            }
        }

        #endregion
        #region 동기화 여부 - IsSynchronized

        /// <summary>
        /// 동기화 여부
        /// </summary>
        public virtual bool IsSynchronized
        {
            get
            {
                return this.managementObjectCollection.IsSynchronized;
            }
        }

        #endregion
        #region 동기 루트 - SyncRoot

        /// <summary>
        /// 동기 루트
        /// </summary>
        public virtual object SyncRoot
        {
            get
            {
                return this;
            }
        }

        #endregion

        //////////////////////////////////////////////////////////////////////////////////////////////////// Constructor
        ////////////////////////////////////////////////////////////////////////////////////////// Public

        #region 생성자 - BIOSCollection(managementObjectCollection)

        /// <summary>
        /// 생성자
        /// </summary>
        /// <param name="managementObjectCollection">관리 객체 컬렉션</param>
        public BIOSCollection(ManagementObjectCollection managementObjectCollection)
        {
            this.managementObjectCollection = managementObjectCollection;
        }

        #endregion

        //////////////////////////////////////////////////////////////////////////////////////////////////// Method
        ////////////////////////////////////////////////////////////////////////////////////////// Public

        #region 복사하기 - CopyTo(array, index)

        /// <summary>
        /// 복사하기
        /// </summary>
        /// <param name="array">배열</param>
        /// <param name="index">인덱스</param>
        public virtual void CopyTo(Array array, int index)
        {
            this.managementObjectCollection.CopyTo(array, index);

            int count;

            for(count = 0; count < array.Length; count++)
            {
                array.SetValue(new BIOS((ManagementObject)array.GetValue(count)), count);
            }
        }

        #endregion
        #region 열거자 구하기 - GetEnumerator()

        /// <summary>
        /// 열거자 구하기
        /// </summary>
        /// <returns>열거자</returns>
        public virtual IEnumerator GetEnumerator()
        {
            return new BIOSEnumerator(this.managementObjectCollection.GetEnumerator());
        }

        #endregion
    }
}
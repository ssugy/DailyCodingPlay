﻿using System.ComponentModel;
using System.Management;

namespace TestProject
{
    /// <summary>
    /// 관리 시스템 속성
    /// </summary>
    [TypeConverter(typeof(ExpandableObjectConverter))]
    public class ManagementSystemProperties
    {
        //////////////////////////////////////////////////////////////////////////////////////////////////// Field
        ////////////////////////////////////////////////////////////////////////////////////////// Private

        #region Field

        /// <summary>
        /// 관리 기본 객체
        /// </summary>
        private ManagementBaseObject managementBaseObject;

        #endregion

        //////////////////////////////////////////////////////////////////////////////////////////////////// Property
        ////////////////////////////////////////////////////////////////////////////////////////// Public

        #region 속 - GENUS

        /// <summary>
        /// 속
        /// </summary>
        [Browsable(true)]
        public int GENUS
        {
            get
            {
                return (int)(this.managementBaseObject["__GENUS"]);
            }
        }

        #endregion
        #region 클래스 - CLASS

        /// <summary>
        /// 클래스
        /// </summary>
        [Browsable(true)]
        public string CLASS
        {
            get
            {
                return (string)(this.managementBaseObject["__CLASS"]);
            }
        }

        #endregion
        #region 수퍼 클래스 - SUPERCLASS

        /// <summary>
        /// 수퍼 클래스
        /// </summary>
        [Browsable(true)]
        public string SUPERCLASS
        {
            get
            {
                return (string)(this.managementBaseObject["__SUPERCLASS"]);
            }
        }

        #endregion
        #region 왕조 - DYNASTY

        /// <summary>
        /// 왕조
        /// </summary>
        [Browsable(true)]
        public string DYNASTY
        {
            get
            {
                return (string)(this.managementBaseObject["__DYNASTY"]);
            }
        }

        #endregion
        #region 상대 경로 - RELPATH

        /// <summary>
        /// 상대 경로
        /// </summary>
        [Browsable(true)]
        public string RELPATH
        {
            get
            {
                return (string)(this.managementBaseObject["__RELPATH"]);
            }
        }

        #endregion
        #region 속성 수 - PROPERTY_COUNT

        /// <summary>
        /// 속성 수
        /// </summary>
        [Browsable(true)]
        public int PROPERTY_COUNT
        {
            get
            {
                return (int)(this.managementBaseObject["__PROPERTY_COUNT"]);
            }
        }

        #endregion
        #region 파생 - DERIVATION

        /// <summary>
        /// 파생
        /// </summary>
        [Browsable(true)]
        public string[] DERIVATION
        {
            get
            {
                return (string[])(this.managementBaseObject["__DERIVATION"]);
            }
        }

        #endregion
        #region 서버 - SERVER

        /// <summary>
        /// 서버
        /// </summary>
        [Browsable(true)]
        public string SERVER
        {
            get
            {
                return (string)(this.managementBaseObject["__SERVER"]);
            }
        }

        #endregion
        #region 네임스페이스 - NAMESPACE

        /// <summary>
        /// 네임스페이스
        /// </summary>
        [Browsable(true)]
        public string NAMESPACE
        {
            get
            {
                return (string)(this.managementBaseObject["__NAMESPACE"]);
            }
        }

        #endregion
        #region 경로 - PATH

        /// <summary>
        /// 경로
        /// </summary>
        [Browsable(true)]
        public string PATH
        {
            get
            {
                return (string)(this.managementBaseObject["__PATH"]);
            }
        }

        #endregion

        //////////////////////////////////////////////////////////////////////////////////////////////////// Constructor
        ////////////////////////////////////////////////////////////////////////////////////////// Public

        #region 생성자 - ManagementSystemProperties(managementBaseObject)

        /// <summary>
        /// 생성자
        /// </summary>
        /// <param name="managementBaseObject">관리 기본 객체</param>
        public ManagementSystemProperties(ManagementBaseObject managementBaseObject)
        {
            this.managementBaseObject = managementBaseObject;
        }

        #endregion
    }
}
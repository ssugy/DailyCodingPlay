﻿using System;
using System.Collections;
using System.ComponentModel;
using System.Globalization;

namespace TestProject
{
    /// <summary>
    /// WMI 값 타입 컨버터
    /// </summary>
    public class WMIValueTypeConverter : TypeConverter
    {
        //////////////////////////////////////////////////////////////////////////////////////////////////// Field
        ////////////////////////////////////////////////////////////////////////////////////////// Private

        #region Field

        /// <summary>
        /// 기본 컨버터
        /// </summary>
        private TypeConverter baseConverter;
            
        /// <summary>
        /// 기본 타입
        /// </summary>
        private Type baseType;

        #endregion

        //////////////////////////////////////////////////////////////////////////////////////////////////// Constructor
        ////////////////////////////////////////////////////////////////////////////////////////// Public

        #region 생성자 - WMIValueTypeConverter(baseType)

        /// <summary>
        /// 생성자
        /// </summary>
        /// <param name="baseType">기본 타입</param>
        public WMIValueTypeConverter(Type baseType)
        {
            this.baseConverter = TypeDescriptor.GetConverter(baseType);

            this.baseType = baseType;
        }

        #endregion

        //////////////////////////////////////////////////////////////////////////////////////////////////// Method
        ////////////////////////////////////////////////////////////////////////////////////////// Public

        #region 변환 가능 여부 구하기 - CanConvertFrom(context, sourceType)

        /// <summary>
        /// 변환 가능 여부 구하기
        /// </summary>
        /// <param name="context">컨텍스트</param>
        /// <param name="sourceType">소스 타입</param>
        /// <returns>변환 가능 여부</returns>
        public override bool CanConvertFrom(ITypeDescriptorContext context, Type sourceType)
        {
            return this.baseConverter.CanConvertFrom(context, sourceType);
        }

        #endregion
        #region 변환 가능 여부 구하기 - CanConvertTo(context, targetType)

        /// <summary>
        /// 변환 가능 여부 구하기
        /// </summary>
        /// <param name="context">컨텍스트</param>
        /// <param name="targetType">타겟 타입</param>
        /// <returns>변환 가능 여부</returns>
        public override bool CanConvertTo(ITypeDescriptorContext context, Type targetType)
        {
            return this.baseConverter.CanConvertTo(context, targetType);
        }

        #endregion

        #region 변환하기 - ConvertFrom(context, cultureInfo, value)

        /// <summary>
        /// 변환하기
        /// </summary>
        /// <param name="context">컨텍스트</param>
        /// <param name="cultureInfo">문화 정보</param>
        /// <param name="value">값</param>
        /// <returns>변환 값</returns>
        public override object ConvertFrom(ITypeDescriptorContext context, CultureInfo cultureInfo, object value)
        {
            return this.baseConverter.ConvertFrom(context, cultureInfo, value);
        }

        #endregion
        #region 변환하기 - ConvertTo(context, cultureInfo, value, targetType)

        /// <summary>
        /// 변환하기
        /// </summary>
        /// <param name="context">컨텍스트</param>
        /// <param name="cultureInfo">문화 정보</param>
        /// <param name="value">값</param>
        /// <param name="targetType">타겟 타입</param>
        /// <returns>변환 값</returns>
        public override object ConvertTo(ITypeDescriptorContext context, CultureInfo cultureInfo, object value, Type targetType)
        {
            if(this.baseType.BaseType == typeof(Enum))
            {
                if(value.GetType() == targetType)
                {
                    return value;
                }

                if((value == null) && (context != null) && (context.PropertyDescriptor.ShouldSerializeValue(context.Instance) == false))
                {
                    return  "Null" ;
                }

                return this.baseConverter.ConvertTo(context, cultureInfo, value, targetType);
            }

            if((this.baseType == typeof(bool)) && (this.baseType.BaseType == typeof(System.ValueType)))
            {
                if((value == null) && (context != null) && (context.PropertyDescriptor.ShouldSerializeValue(context.Instance) == false))
                {
                    return "";
                }

                return this.baseConverter.ConvertTo(context, cultureInfo, value, targetType);
            }

            if((context != null) && (context.PropertyDescriptor.ShouldSerializeValue(context.Instance) == false))
            {
                return "";
            }

            return this.baseConverter.ConvertTo(context, cultureInfo, value, targetType);
        }

        #endregion

        #region 인스턴스 생성하기 - CreateInstance(context, dictionary)

        /// <summary>
        /// 인스턴스 생성하기
        /// </summary>
        /// <param name="context">컨텍스트</param>
        /// <param name="dictionary">딕셔너리</param>
        /// <returns>인스턴스</returns>
        public override object CreateInstance(ITypeDescriptorContext context, IDictionary dictionary)
        {
            return this.baseConverter.CreateInstance(context, dictionary);
        }

        #endregion
        #region 인스턴스 생성 지원 여부 구하기 - GetCreateInstanceSupported(context)

        /// <summary>
        /// 인스턴스 생성 지원 여부 구하기
        /// </summary>
        /// <param name="context">컨텍스트</param>
        /// <returns>인스턴스 생성 지원 여부</returns>
        public override bool GetCreateInstanceSupported(ITypeDescriptorContext context)
        {
            return this.baseConverter.GetCreateInstanceSupported(context);
        }

        #endregion
        #region 속성 컬렉션 구하기 - GetProperties(context, value, attributeArray)

        /// <summary>
        /// 속성 컬렉션 구하기
        /// </summary>
        /// <param name="context">컨텍스트</param>
        /// <param name="value">값</param>
        /// <param name="attributeArray">특성 배열</param>
        /// <returns>속성 컬렉션</returns>
        public override PropertyDescriptorCollection GetProperties(ITypeDescriptorContext context, object value, Attribute[] attributeArray)
        {
            return this.baseConverter.GetProperties(context, value, attributeArray);
        }

        #endregion
        #region 속성 컬렉션 지원 여부 구하기 - GetPropertiesSupported(context)

        /// <summary>
        /// 속성 컬렉션 지원 여부 구하기
        /// </summary>
        /// <param name="context">컨텍스트</param>
        /// <returns>속성 컬렉션 지원 여부</returns>
        public override bool GetPropertiesSupported(ITypeDescriptorContext context)
        {
            return this.baseConverter.GetPropertiesSupported(context);
        }

        #endregion
        #region 표준 값 컬렉션 구하기 - GetStandardValues(context)

        /// <summary>
        /// 표준 값 컬렉션 구하기
        /// </summary>
        /// <param name="context">컨텍스트</param>
        /// <returns>표준 값 컬렉션</returns>
        public override TypeConverter.StandardValuesCollection GetStandardValues(ITypeDescriptorContext context)
        {
            return this.baseConverter.GetStandardValues(context);
        }

        #endregion
        #region 배타적 표준 값 컬렉션 구하기 - GetStandardValuesExclusive(context)

        /// <summary>
        /// 배타적 표준 값 컬렉션 구하기
        /// </summary>
        /// <param name="context">컨텍스트</param>
        /// <returns>배타적 표준 값 컬렉션</returns>
        public override bool GetStandardValuesExclusive(ITypeDescriptorContext context)
        {
            return this.baseConverter.GetStandardValuesExclusive(context);
        }

        #endregion
        #region 표준 값 컬렉션 지원 여부 구하기 - GetStandardValuesSupported(context)

        /// <summary>
        /// 표준 값 컬렉션 지원 여부 구하기
        /// </summary>
        /// <param name="context">컨텍스트</param>
        /// <returns>표준 값 컬렉션 지원 여부</returns>
        public override bool GetStandardValuesSupported(ITypeDescriptorContext context)
        {
            return this.baseConverter.GetStandardValuesSupported(context);
        }

        #endregion
    }
}
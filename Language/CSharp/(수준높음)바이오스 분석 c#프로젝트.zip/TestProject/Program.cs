﻿using System;

namespace TestProject
{
    /// <summary>
    /// 프로그램
    /// </summary>
    class Program
    {
        //////////////////////////////////////////////////////////////////////////////////////////////////// Method
        ////////////////////////////////////////////////////////////////////////////////////////// Static
        //////////////////////////////////////////////////////////////////////////////// Private

        #region 프로그램 시작하기 - Main()

        /// <summary>
        /// 프로그램 시작하기
        /// </summary>
        private static void Main()
        {
            Console.Title = "ManagementObject 클래스 : BIOS 정보 구하기";

            foreach(BIOS bios in BIOS.GetInstances())
            {
                Console.WriteLine("NAME          : " + bios.Name);
                Console.WriteLine("CAPTION       : " + bios.Caption);
                Console.WriteLine("SERIAL NUMBER : " + bios.SerialNumber);
                Console.WriteLine("STATUS        : " + bios.Status);
                Console.WriteLine("VERSION       : " + bios.Version);
                Console.WriteLine("MANUFACTURER  : " + bios.Manufacturer);
            }
        }

        #endregion
    }
}
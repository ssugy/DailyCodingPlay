﻿namespace TestProject
{
    /// <summary>
    /// BIOS 특징 값
    /// </summary>
    public enum BIOSCharacteristicsValue
    {
        /// <summary>
        /// Reserved
        /// </summary>
        Reserved = 0,
            
        /// <summary>
        /// Reserved0
        /// </summary>
        Reserved0 = 1,
            
        /// <summary>
        /// Unknown0
        /// </summary>
        Unknown0 = 2,
            
        /// <summary>
        /// BIOSCharacteristicsNotSupported
        /// </summary>
        BIOSCharacteristicsNotSupported = 3,
            
        /// <summary>
        /// ISAIsSupported
        /// </summary>
        ISAIsSupported = 4,
            
        /// <summary>
        /// MCAIsSupported
        /// </summary>
        MCAIsSupported = 5,
            
        /// <summary>
        /// EISAIsSupported
        /// </summary>
        EISAIsSupported = 6,
            
        /// <summary>
        /// PCIIsSupported
        /// </summary>
        PCIIsSupported = 7,
            
        /// <summary>
        /// PCCardPCMCIAIsSupported
        /// </summary>
        PCCardPCMCIAIsSupported = 8,
            
        /// <summary>
        /// PlugAndPlayIsSupported
        /// </summary>
        PlugAndPlayIsSupported = 9,
            
        /// <summary>
        /// APMIsSupported
        /// </summary>
        APMIsSupported = 10,
            
        /// <summary>
        /// BIOSIsUpgradeableFlash
        /// </summary>
        BIOSIsUpgradeableFlash = 11,
            
        /// <summary>
        /// BIOSShadowingIsAllowed
        /// </summary>
        BIOSShadowingIsAllowed = 12,
            
        /// <summary>
        /// VLVESAIsSupported
        /// </summary>
        VLVESAIsSupported = 13,
            
        /// <summary>
        /// ESCDSupportIsAvailable
        /// </summary>
        ESCDSupportIsAvailable = 14,
            
        /// <summary>
        /// BootFromCDIsSupported
        /// </summary>
        BootFromCDIsSupported = 15,
            
        /// <summary>
        /// SelectableBootIsSupported
        /// </summary>
        SelectableBootIsSupported = 16,
            
        /// <summary>
        /// BIOSROMIsSocketed
        /// </summary>
        BIOSROMIsSocketed = 17,
            
        /// <summary>
        /// BootFromPCCardPCMCIAIsSupported
        /// </summary>
        BootFromPCCardPCMCIAIsSupported = 18,
            
        /// <summary>
        /// EDDEnhancedDiskDriveSpecificationIsSupported
        /// </summary>
        EDDEnhancedDiskDriveSpecificationIsSupported = 19,
            
        /// <summary>
        /// Int13hJapaneseFloppyForNEC9800_1_2mb_3_5_1kBytesSector360RPMIsSupported
        /// </summary>
        Int13hJapaneseFloppyForNEC9800_1_2mb_3_5_1kBytesSector360RPMIsSupported = 20,
            
        /// <summary>
        /// Int13hJapaneseFloppyForToshiba_1_2mb_3_5_360RPMIsSupported
        /// </summary>
        Int13hJapaneseFloppyForToshiba_1_2mb_3_5_360RPMIsSupported = 21,
            
        /// <summary>
        /// Int13h_5_25_360KBFloppyServicesAreSupported
        /// </summary>
        Int13h_5_25_360KBFloppyServicesAreSupported = 22,
            
        /// <summary>
        /// Int13h_5_25_1_2MBFloppyServicesAreSupported
        /// </summary>
        Int13h_5_25_1_2MBFloppyServicesAreSupported = 23,
            
        /// <summary>
        /// Int13h_3_5_720KBFloppyServicesAreSupported
        /// </summary>
        Int13h_3_5_720KBFloppyServicesAreSupported = 24,
            
        /// <summary>
        /// Int13h_3_5_2_88MBFloppyServicesAreSupported
        /// </summary>
        Int13h_3_5_2_88MBFloppyServicesAreSupported = 25,
            
        /// <summary>
        /// Int5hPrintScreenServiceIsSupported
        /// </summary>
        Int5hPrintScreenServiceIsSupported = 26,
            
        /// <summary>
        /// Int9h8042KeyboardServicesAreSupported
        /// </summary>
        Int9h8042KeyboardServicesAreSupported = 27,
            
        /// <summary>
        /// Int14hSerialServicesAreSupported
        /// </summary>
        Int14hSerialServicesAreSupported = 28,
            
        /// <summary>
        /// Int17hPrinterServicesAreSupported
        /// </summary>
        Int17hPrinterServicesAreSupported = 29,
            
        /// <summary>
        /// Int10hCGAMonoVideoServicesAreSupported
        /// </summary>
        Int10hCGAMonoVideoServicesAreSupported = 30,
            
        /// <summary>
        /// NecPc98
        /// </summary>
        NecPc98 = 31,
            
        /// <summary>
        /// ACPISupported
        /// </summary>
        ACPISupported = 32,
            
        /// <summary>
        /// USBLegacyIsSupported
        /// </summary>
        USBLegacyIsSupported = 33,
            
        /// <summary>
        /// AGPIsSupported
        /// </summary>
        AGPIsSupported = 34,
            
        /// <summary>
        /// I2OBootIsSupported
        /// </summary>
        I2OBootIsSupported = 35,
            
        /// <summary>
        /// LS120BootIsSupported
        /// </summary>
        LS120BootIsSupported = 36,
            
        /// <summary>
        /// AtapiZipDriveBootIsSupported
        /// </summary>
        AtapiZipDriveBootIsSupported = 37,
            
        /// <summary>
        /// V1394BootIsSupported
        /// </summary>
        V1394BootIsSupported = 38,
            
        /// <summary>
        /// SmartBatterySupported
        /// </summary>
        SmartBatterySupported = 39,
            
        /// <summary>
        /// Null
        /// </summary>
        Null = 40,
    }
}